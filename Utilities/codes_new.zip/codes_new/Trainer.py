import torch
import copy
from AutoDiff import AG_grad
from pinns_weights import*

__all__ = ["Trainer"]

class Trainer:
    def __init__(self, model, *args, **kwargs):
        
        self._model = model
        self._weights = model.weights
        self.parameters = model.parameters
        self.zero_grad = model.zero_grad
        self.device = model.device
        self.net = model.net
        self.net_grad = model.net_grad
        self.net_res = model.net_res
        self.state_dict = model.state_dict

        self.optimizer = None
        self.lr_scheduler = None
        self.loss_weights = None
        self.LM = None
        
    @torch.no_grad
    def l2_error(self, inputs, targets, dims=None):
        if dims is not None:
            outputs = self.net(*inputs)[dims]
        else:
            outputs = self.net(*inputs)
        assert type(outputs) == type(targets)
        if torch.is_tensor(outputs):
            error = torch.linalg.norm(targets - outputs, 2) / torch.linalg.norm(targets, 2)
            return error.item()
        else:
            error = tuple((torch.linalg.norm(targets[i] - out, 2) / torch.linalg.norm(targets[i], 2)).item() for i, out in enumerate(outputs))
            return error

    @staticmethod
    def mse_error(outputs, targets=0):
        error = (targets - outputs)
        loss = error.pow(2).mean()
        return loss, error

    def compute_weights(self, scheme, losses, weights, **kwargs):
        if scheme == "lr_anneling":
            return lr_annealing(losses=losses, params=self._weights(), weights=weights, **kwargs)

    def compute_loss(self, scheme, losses, errors, weights=None, **kwargs):
        if scheme is None:
            if weights is None:
                return sum(losses)
            else:
                self.loss_weights = weights
                return sum(w * l for w, l in zip(weights, losses))
        if scheme == "lr_anneling":
            return sum(w * l for w, l in zip(self.loss_weights, losses))
        elif scheme == "penalty":
            return penalty(errors=errors, LM=self.LM, **kwargs)
        elif scheme == "AL":
            return augmented_lagrangian(errors=errors, LM=self.LM, **kwargs)
        elif scheme == "SA":
            return soft_attention(errors=errors, LM=self.LM, **kwargs)
        elif scheme == "rad":
            return rad_loss(errors=errors, weights=weights)
        else:
            raise RuntimeError(f"{scheme} is not supported")

    @torch.no_grad
    def weights_norm(self, *args):
        _norm = list()
        for w in args:
            _norm.append(torch.linalg.norm(w).item())
        return  _norm
    
    def _optim(self, optimizer_name="Adam", params=None, **kwargs):
        if params is None:
            params = self.parameters()
        return getattr(torch.optim, optimizer_name)(params, **kwargs)

    def _exp_lr_scheduler(self, optimizer, decay_rate=.9, decay_step=8000):
        _exp_decay = lambda t: decay_rate ** (t / decay_step)
        return torch.optim.lr_scheduler.LambdaLR(optimizer, _exp_decay)

    def step(self, closure):
        if self.optimizer is not None:
            loss = self.optimizer.step(closure)
        if self.lr_scheduler is not None:
            self.lr_scheduler.step()
        return loss
    
    # SAVE
    def save(self, losses=True, weights=False, optimizer=False, file=''):
        if losses:
            for key, val in self.losses.items():
                np.savetxt(file + 'loss_' + key, val)
        if weights:
            for key, val in self.weights_history.items():
                np.savetxt(file + 'weight_' + key, val)
        if optimizer:
            optimizer_dict = {
                'optimizer': self.optimizer.state_dict(),
                'lr_sched': None,
            }
            torch.save(optimizer_dict, "optim.pth")

    def save_checkpoint(self, epoch):
        checkpoint = {
            'epoch': epoch,
            'model': self.state_dict()
        }
        torch.save(checkpoint, f'checkpoint_{epoch}.pth')

    def check_if_best(val):
        if val == min(self.losses['l2']):
            best_model = copy.deepcopy(self.state_dict())