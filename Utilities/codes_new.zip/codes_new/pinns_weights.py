import torch
from AutoDiff import AG_grad

__all__ = ["lr_annealing", "_new_params", "penalty", "augmented_lagrangian", "soft_attention", "rad_loss"]

# Learning rate annealing algorithme:
def _grad_losses(losses, params, func=lambda x: x):
    params = tuple(params)
    grads = list()
    for loss in losses:
        grad = AG_grad(loss, params)
        grad = torch.cat([g.detach().view(-1) for g in grad])
        grads.append(func(grad))
    return grads

"""
def lr_annealing(
        losses,
        params,
        weights=None,
        res_indices=None,
        alpha=0.6,
        sup=1e5,
        **kwargs
):
    if weights is None:
        weights = [1. for _ in losses]
    if res_indices is None:
        res_indices = [len(losses) - 1]
    grads = _grad_losses(losses, params)
    res_grads = [weights[i] * grads[i] for i in res_indices]
    max_res = sum(res_grads).abs().max().item()
    new_weights = weights[:]
    eps = 0
    for i, (w, grad) in enumerate(zip(weights, grads)):
        if i in res_indices:
            pass
        else:
            m = grad.abs().mean().item()
            w = (1. - alpha) * w + alpha * (max_res / (w * m + eps))
            new_weights[i] = min(sup, w)
    return new_weights
"""

def lr_annealing(
        losses,
        params,
        weights=None,
        res_indices=None,
        alpha=0.6,
        sup=1e5,
        **kwargs
):
    grads = _grad_losses(losses, params)

    w_ics, w_bcs, w_res = weights
    v_ics = grads[0].abs().mean()
    v_bcs = grads[1].abs().mean()
    v_res = grads[2].abs().max()

    w_ics = (1 - alpha) * w_ics + (alpha / w_ics) * (v_res / v_ics)
    w_bcs = (1 - alpha) * w_bcs + (alpha / w_bcs) * (v_res / v_bcs)
    w_res = 1.

    weights = [w_ics.item(), w_bcs.item(), w_res]
    return weights


# define the Lagrange multiplier (weights adjusted using GD):
def _new_params(*args, device, copy=None):
    if copy is None:
        copy = [1 for _ in args]
    params = torch.nn.ParameterList()
    for i, n in enumerate(args):
        data = torch.rand((n, 1), device=device)
        param = torch.nn.Parameter(data)
        for _ in range(copy[i]):
            params.append(param)
    return params

# Penalty method:
def penalty(
        errors,
        LM,
        indices=None,
        copy=None,
        **kwargs
):
    if indices is None:
        indices = [len(errors) - 1]
    loss = sum(errors[i].pow(2).mean() for i in indices)
    errors = [errors[i] for i in set(range(len(errors))) - set(indices)]
    if copy is not None:
        _LM = []
        for i, p in enumerate(LM):
            for _ in range(copy[i]):
                _LM.append(p)
    else:
        _LM = LM

    for i, e in enumerate(errors):
        c = _LM[i] * e.pow(2)
        loss += c.mean()
    return loss

# Augmented Lagrangian method:
def augmented_lagrangian(
        errors,
        LM,
        indices=None,
        beta=1.,
        copy=None,
        **kwargs
):
    if indices is None:
        indices = [len(errors) - 1]
    loss = sum(errors[i].pow(2).mean() for i in indices)
    errors = [errors[i] for i in set(range(len(errors))) - set(indices)]
    if copy is not None:
        _LM = []
        for i, p in enumerate(LM):
            for _ in range(copy[i]):
                _LM.append(p)
    else:
        _LM = LM

    for i, e in enumerate(errors):
        c = beta * e.pow(2) + _LM[i] * e
        loss += c.mean()
    return loss

# Soft Attention mechanism:
def soft_attention(
        errors,
        LM,
        mask_fn,
        copy=None,
        **kwargs
):
    if copy is not None:
        _LM = []
        for i, p in enumerate(LM):
            for _ in range(copy[i]):
                _LM.append(p)
    else:
        _LM = LM
    if callable(mask_fn):
        fn = len(_LM) *  [mask_fn]
    else:
        fn = mask_fn

    loss = 0.
    for i, (w, e) in enumerate(zip(_LM, errors)):
        c = fn[i](w) * e.pow(2)
        loss += c.mean()
    return loss

# NTK weighting: Soon!
# EW_functions:

def rad_loss(errors, weights):
    loss = 0
    for i, error in enumerate(errors):
        loss += (weights[i] * error.pow(2)).mean()
    return loss